package com.konibee.bible;

import com.konibee.bible.R;

import android.app.Activity;
import android.os.Bundle;

public class GoToBible extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gotobible);		
	}
}
